﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;

namespace ProdajaUlaznica
{
    public partial class KupnjaUlaznice : Form
    {
        static List<KupnjaUlazniceKorisnik> ListaUlaznicaKorisnika = new List<KupnjaUlazniceKorisnik>();
        static string pathdocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        static string xmlfile = "UlazniceKorisnici.xml";
        static string path = Path.Combine(pathdocuments, xmlfile);


        public KupnjaUlaznice()
        {
            InitializeComponent();
        }

        private void btnKupnja_Click(object sender, EventArgs e)
        {
          


            KupnjaUlazniceKorisnik UlaznicaKorisnika = new KupnjaUlazniceKorisnik(Convert.ToInt32(txtBxOIBUlaznica.Text), txtBxPrezimeUlaznica.Text, txtBxImeUlaznica.Text, comBxSektor.Text, Convert.ToString(datumRodenjaUlaznica.Value));
            ListaUlaznicaKorisnika.Add(UlaznicaKorisnika);
            DialogResult dialogResult = MessageBox.Show("Želite li kupiti još jednu ulaznicu?", "Kupnja", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
            {
                try
                {
                    var KorisniciUlaznica = XDocument.Load(path);
                    foreach (KupnjaUlazniceKorisnik korisnikUlaznica in ListaUlaznicaKorisnika)
                    {
                        var Korisnik = new XElement("Korisnik",
                            new XElement("ID", korisnikUlaznica.ID1),
                            new XElement("Ime", korisnikUlaznica.Ime1),
                            new XElement("Prezime", korisnikUlaznica.Prezime1),
                        new XElement("Sektor", korisnikUlaznica.Sektor1),
                        new XElement("Datumrodenja", korisnikUlaznica.DatumRodenja1));
                        KorisniciUlaznica.Root.Add(Korisnik);

                    }
                    KorisniciUlaznica.Save(path);
                }
                catch (Exception ex)
                {
                    var KorisniciUlaznica = new XDocument();
                    KorisniciUlaznica.Add(new XElement("Korisnici"));
                    foreach (KupnjaUlazniceKorisnik korisnikUlaznica in ListaUlaznicaKorisnika)
                    {
                        var Korisnik = new XElement("Korisnik",
                           new XElement("ID", korisnikUlaznica.ID1),
                           new XElement("Ime", korisnikUlaznica.Ime1),
                           new XElement("Prezime", korisnikUlaznica.Prezime1),
                       new XElement("Sektor", korisnikUlaznica.Sektor1),
                       new XElement("Datumrodenja", korisnikUlaznica.DatumRodenja1));

                        KorisniciUlaznica.Root.Add(Korisnik);
                    }

                    KorisniciUlaznica.Save(path);

                }
                ListaUlaznicaKorisnika.Clear();
                this.Close();
            }
            txtBxImeUlaznica.Text = "";
            txtBxPrezimeUlaznica.Text = "";
           txtBxOIBUlaznica.Text = "";

        }
    }
}
